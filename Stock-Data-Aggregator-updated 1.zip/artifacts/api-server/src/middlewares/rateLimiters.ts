import rateLimit from "express-rate-limit";

/**
 * General-purpose limiter applied to the entire /api surface.
 * Generous enough not to bother normal usage, but stops a runaway
 * client-side loop (or a single misbehaving browser tab) from
 * hammering the server and the external APIs (Yahoo Finance) behind it.
 */
export const generalApiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  limit: 300, // ~20 requests/minute sustained, plenty for normal dashboard use
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests. Please slow down and try again shortly." },
});

/**
 * Stricter limiter for endpoints that call OpenAI. These are the most
 * expensive requests in the app (both in latency and in $ per call), so
 * they get their own, much tighter budget on top of the general limiter.
 */
export const aiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "AI analysis rate limit reached. Please wait a few minutes and try again." },
});
