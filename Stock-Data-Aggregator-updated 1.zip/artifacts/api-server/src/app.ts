import express, { type Express } from "express";
import helmet from "helmet";
import pinoHttp from "pino-http";
import { clerkMiddleware } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import router from "./routes";
import { logger } from "./lib/logger";
import {
  CLERK_PROXY_PATH,
  clerkProxyMiddleware,
  getClerkProxyHost,
} from "./middlewares/clerkProxyMiddleware";
import { generalApiLimiter } from "./middlewares/rateLimiters";

const app: Express = express();

// Baseline security headers (nosniff, no X-Powered-By, HSTS, etc.).
// This app only ever returns JSON — it does not render HTML pages that get
// embedded in an iframe (the frontend is a separate Vite app) — so we turn
// off Content-Security-Policy and cross-origin-embedder-policy here rather
// than inherit helmet's strict HTML-oriented defaults, which are meant for
// servers that render pages and could otherwise surprise a future change
// that does serve HTML (e.g. an error page) from this server.
app.use(
  helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false,
  }),
);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
  clerkMiddleware((req) => ({
    publishableKey: publishableKeyFromHost(
      getClerkProxyHost(req) ?? "",
      process.env.CLERK_PUBLISHABLE_KEY,
    ),
  })),
);

app.use("/api", generalApiLimiter, router);

export default app;
