import { FormEvent, useState } from "react";
import { Bookmark, Link2, Plus, Star, Trash2, X } from "lucide-react";
import { useFetchArticleMetadata } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import type { WatchlistItem } from "@/hooks/useWatchlist";
import {
  MAX_TRACKED_ARTICLES,
  MAX_TRACKED_ARTICLES_PER_TICKER,
  type TrackedArticle,
} from "@/hooks/useTrackedArticles";
import { SECTOR_ETF_BY_NAME } from "@/lib/marketSectors";

type AddArticleInput = Omit<TrackedArticle, "id" | "ticker" | "addedAt">;
type ArticleDraft = {
  url: string;
  title: string;
  summary: string;
  source: string;
  metadataUrl: string;
  publishedAt?: string;
  articleType?: TrackedArticle["articleType"];
};

const EMPTY_ARTICLE_DRAFT: ArticleDraft = {
  url: "",
  title: "",
  summary: "",
  source: "",
  metadataUrl: "",
};

const ARTICLE_TYPE_LABELS: Record<NonNullable<TrackedArticle["articleType"]>, string> = {
  earnings: "דוחות ותוצאות",
  legal: "משפטי",
  merger: "מיזוגים ורכישות",
  product: "מוצר והשקה",
  leadership: "הנהלה",
  regulation: "רגולציה",
  analyst: "אנליסטים",
  market: "שוק ומסחר",
  other: "חדשות כלליות",
};

export function WatchlistManager({
  watchlist,
  trackedArticles,
  onAddTicker,
  onRemoveTicker,
  onAddArticle,
  onRemoveArticle,
}: {
  watchlist: WatchlistItem[];
  trackedArticles: Record<string, TrackedArticle[]>;
  onAddTicker: (ticker: string) => Promise<string | null>;
  onRemoveTicker: (ticker: string) => void;
  onAddArticle: (ticker: string, article: AddArticleInput) => boolean;
  onRemoveArticle: (ticker: string, id: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [ticker, setTicker] = useState("");
  const [tickerError, setTickerError] = useState("");
  const [addingTicker, setAddingTicker] = useState(false);
  const [articleDrafts, setArticleDrafts] = useState<Record<string, ArticleDraft>>({});
  const [articleError, setArticleError] = useState("");
  const [metadataTicker, setMetadataTicker] = useState<string | null>(null);
  const { mutate: fetchArticleMetadata } = useFetchArticleMetadata();
  const sectorGroups = [...new Map(
    watchlist.flatMap((item) => {
      const etf = item.sector ? SECTOR_ETF_BY_NAME[item.sector] : null;
      return etf ? [[etf, item.sector!] as const] : [];
    }),
  )].map(([ticker, sector]) => ({
    ticker,
    companyName: `מעקב סקטוריאלי: ${sector}`,
    sector,
    kind: "sector" as const,
  }));
  const managedItems = [
    ...watchlist.map((item) => ({ ...item, kind: "stock" as const })),
    ...sectorGroups,
  ];

  const handleAddTicker = async (event: FormEvent) => {
    event.preventDefault();
    const normalizedTicker = ticker.trim().toUpperCase();
    if (!/^[A-Z]{1,6}$/.test(normalizedTicker)) {
      setTickerError("יש להזין טיקר באנגלית, באורך של 1–6 תווים.");
      return;
    }
    if (watchlist.some((item) => item.ticker === normalizedTicker)) {
      setTickerError("הטיקר כבר נמצא ברשימת המעקב.");
      return;
    }
    if (watchlist.length >= 20) {
      setTickerError("ניתן לעקוב אחר עד 20 טיקרים בכל פעם.");
      return;
    }

    setTickerError("");
    setAddingTicker(true);
    const error = await onAddTicker(normalizedTicker);
    setAddingTicker(false);
    if (error) {
      setTickerError(error);
      return;
    }
    setTicker("");
  };

  const handleAddArticle = (event: FormEvent, item: Pick<WatchlistItem, "ticker">) => {
    event.preventDefault();
    const draft = articleDrafts[item.ticker] ?? EMPTY_ARTICLE_DRAFT;
    const url = draft.url.trim();
    const title = draft.title.trim();
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(url);
    } catch {
      setArticleError("יש להזין קישור מלא לכתבה, כולל https://.");
      return;
    }
    if (!["http:", "https:"].includes(parsedUrl.protocol)) {
      setArticleError("ניתן לשמור רק קישורי http או https.");
      return;
    }
    if ((trackedArticles[item.ticker] ?? []).length >= MAX_TRACKED_ARTICLES_PER_TICKER) {
      setArticleError(`ניתן לשמור עד ${MAX_TRACKED_ARTICLES_PER_TICKER} כתבות עבור כל טיקר.`);
      return;
    }
    if (Object.values(trackedArticles).flat().length >= MAX_TRACKED_ARTICLES) {
      setArticleError(`ניתן לשמור עד ${MAX_TRACKED_ARTICLES} כתבות לכל רשימת המעקב.`);
      return;
    }

    const saveArticle = (article: AddArticleInput, notice?: string) => {
      const added = onAddArticle(item.ticker, article);
      if (!added) {
        setArticleError("הכתבה הזו כבר שמורה עבור הטיקר.");
        return;
      }
      setArticleError(notice ?? "");
      setArticleDrafts((previous) => ({
        ...previous,
        [item.ticker]: EMPTY_ARTICLE_DRAFT,
      }));
    };

    const saveWithMetadata = (metadata?: {
      title: string;
      source: string;
      publishedAt: string;
      summary: string;
      articleType: NonNullable<TrackedArticle["articleType"]>;
    }) => {
      saveArticle({
        title: title || metadata?.title || "",
        url,
        source: draft.source || metadata?.source || parsedUrl.hostname.replace(/^www\./, ""),
        publishedAt: draft.publishedAt || metadata?.publishedAt || new Date().toISOString(),
        summary: draft.summary.trim() || metadata?.summary || "",
        articleType: draft.articleType || metadata?.articleType || "other",
      });
    };

    setArticleError("");
    if (draft.metadataUrl === url && (draft.title.trim() || title)) {
      saveWithMetadata();
      return;
    }

    setMetadataTicker(item.ticker);
    fetchArticleMetadata(
      { data: { url } },
      {
        onSuccess: (metadata) => {
          setMetadataTicker(null);
          setArticleDrafts((previous) => {
            const current = previous[item.ticker] ?? EMPTY_ARTICLE_DRAFT;
            if (current.url.trim() !== url) return previous;
            return {
              ...previous,
              [item.ticker]: {
                ...current,
                title: current.title.trim() || metadata.title,
                summary: current.summary.trim() || metadata.summary,
                source: metadata.source,
                metadataUrl: url,
                publishedAt: metadata.publishedAt,
                articleType: metadata.articleType,
              },
            };
          });
          saveWithMetadata(metadata);
        },
        onError: () => {
          setMetadataTicker(null);
          if (title) {
            saveArticle({
              title,
              url,
              source: draft.source || parsedUrl.hostname.replace(/^www\./, ""),
              publishedAt: draft.publishedAt || new Date().toISOString(),
              summary: draft.summary.trim(),
              articleType: draft.articleType || "other",
            }, "לא הצלחנו לקרוא את הקישור, לכן נשמרו הפרטים שהזנת ידנית.");
            return;
          }
          setArticleError("לא הצלחנו לקרוא את פרטי הכתבה. אפשר להזין כותרת ותקציר ידנית ולשמור.");
        },
      },
    );
  };

  const handleArticleUrlBlur = (item: Pick<WatchlistItem, "ticker">) => {
    const draft = articleDrafts[item.ticker] ?? EMPTY_ARTICLE_DRAFT;
    const url = draft.url.trim();
    if (!url || draft.metadataUrl === url) return;

    let parsedUrl: URL;
    try {
      parsedUrl = new URL(url);
    } catch {
      return;
    }
    if (!["http:", "https:"].includes(parsedUrl.protocol)) return;

    setArticleError("");
    setMetadataTicker(item.ticker);
    fetchArticleMetadata(
      { data: { url } },
      {
        onSuccess: (metadata) => {
          setMetadataTicker(null);
          setArticleDrafts((previous) => {
            const current = previous[item.ticker] ?? EMPTY_ARTICLE_DRAFT;
            if (current.url.trim() !== url) return previous;
            return {
              ...previous,
              [item.ticker]: {
                ...current,
                title: current.title.trim() || metadata.title,
                summary: current.summary.trim() || metadata.summary,
                source: metadata.source,
                metadataUrl: url,
                publishedAt: metadata.publishedAt,
                articleType: metadata.articleType,
              },
            };
          });
        },
        onError: () => {
          setMetadataTicker(null);
          setArticleError("לא הצלחנו לקרוא את פרטי הכתבה. אפשר להשלים כותרת ותקציר ידנית.");
        },
      },
    );
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="shrink-0 bg-background">
          <Star className="w-4 h-4 ml-2" />
          ניהול מעקב
          <span className="mr-1 rounded-full bg-primary/10 px-1.5 py-0.5 text-[11px] text-primary">
            {watchlist.length}
          </span>
        </Button>
      </DialogTrigger>
      <DialogContent dir="rtl" className="max-w-xl max-h-[85vh] overflow-y-auto">
        <DialogHeader className="text-right">
          <DialogTitle className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-primary" />
            ניהול רשימת מעקב ומקורות
          </DialogTitle>
          <DialogDescription>
            הוסף או הסר טיקרים, והדבק קישור לכתבה כדי לנתח ולשמור אותה בעדיפות בסריקות הבאות.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleAddTicker} className="rounded-lg border border-border bg-muted/20 p-3">
          <div className="flex gap-2">
            <Input
              value={ticker}
              onChange={(event) => {
                setTicker(event.target.value.toUpperCase());
                setTickerError("");
              }}
              placeholder="הוסף טיקר, למשל AAPL"
              aria-label="טיקר להוספה לרשימת המעקב"
              className="font-mono uppercase bg-background"
              maxLength={6}
              disabled={addingTicker}
            />
            <Button type="submit" disabled={addingTicker} className="shrink-0">
              <Plus className="w-4 h-4" />
              {addingTicker ? "בודק..." : "הוסף"}
            </Button>
          </div>
          {tickerError && <p className="mt-2 text-xs text-destructive">{tickerError}</p>}
        </form>

        {watchlist.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border py-8 text-center text-sm text-muted-foreground">
            עדיין אין טיקרים במעקב. הוסף את הראשון למעלה.
          </div>
        ) : (
          <div className="space-y-3">
            {managedItems.map((item) => {
              const articles = trackedArticles[item.ticker] ?? [];
              return (
                <section key={item.ticker} className="rounded-lg border border-border bg-card p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-foreground">{item.ticker}</span>
                        {item.kind === "sector" && (
                          <span className="rounded bg-primary/10 px-2 py-0.5 text-[11px] text-primary">
                            סקטור
                          </span>
                        )}
                        {item.sector && (
                          <span className="truncate rounded bg-muted px-2 py-0.5 text-[11px] text-muted-foreground">
                            {item.sector}
                          </span>
                        )}
                      </div>
                      <p className="mt-0.5 truncate text-xs text-muted-foreground">
                        {item.companyName ?? "שם החברה ייטען בסריקה"}
                      </p>
                    </div>
                    {item.kind === "stock" && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        title={`הסר ${item.ticker} מרשימת המעקב`}
                        aria-label={`הסר ${item.ticker} מרשימת המעקב`}
                        onClick={() => onRemoveTicker(item.ticker)}
                        className="shrink-0 text-muted-foreground hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>

                  <form onSubmit={(event) => handleAddArticle(event, item)} className="mt-3 space-y-2">
                    <Input
                      value={articleDrafts[item.ticker]?.url ?? ""}
                      onChange={(event) => {
                        setArticleError("");
                        setArticleDrafts((previous) => ({
                          ...previous,
                          [item.ticker]: {
                            ...(previous[item.ticker] ?? EMPTY_ARTICLE_DRAFT),
                            url: event.target.value,
                            metadataUrl: "",
                            source: "",
                            publishedAt: undefined,
                            articleType: undefined,
                          },
                        }));
                      }}
                      onBlur={(event) => {
                        if (
                          event.relatedTarget instanceof HTMLButtonElement
                          && event.relatedTarget.type === "submit"
                        ) return;
                        handleArticleUrlBlur(item);
                      }}
                      placeholder="הדבק URL של כתבה למעקב"
                      aria-label={`קישור לכתבה עבור ${item.ticker}`}
                      className="text-xs bg-background"
                      type="url"
                      disabled={metadataTicker === item.ticker}
                    />
                    <div className="flex gap-2">
                      <Input
                        value={articleDrafts[item.ticker]?.title ?? ""}
                        onChange={(event) => {
                          setArticleError("");
                          setArticleDrafts((previous) => ({
                            ...previous,
                            [item.ticker]: {
                              ...(previous[item.ticker] ?? EMPTY_ARTICLE_DRAFT),
                              title: event.target.value,
                            },
                          }));
                        }}
                        placeholder="כותרת (אופציונלי אם הקישור ציבורי)"
                        aria-label={`כותרת הכתבה עבור ${item.ticker}`}
                        className="text-xs bg-background"
                        disabled={metadataTicker === item.ticker}
                      />
                      <Button
                        type="submit"
                        variant="secondary"
                        size="sm"
                        className="shrink-0"
                        disabled={metadataTicker === item.ticker}
                      >
                        <Link2 className="w-3.5 h-3.5" />
                        {metadataTicker === item.ticker ? "מנתח..." : "נתח ושמור"}
                      </Button>
                    </div>
                    <Input
                      value={articleDrafts[item.ticker]?.summary ?? ""}
                      onChange={(event) => {
                        setArticleError("");
                        setArticleDrafts((previous) => ({
                          ...previous,
                          [item.ticker]: {
                            ...(previous[item.ticker] ?? EMPTY_ARTICLE_DRAFT),
                            summary: event.target.value,
                          },
                        }));
                      }}
                      placeholder="תקציר קצר (אופציונלי, משפר את הניתוח)"
                      aria-label={`תקציר הכתבה עבור ${item.ticker}`}
                      className="text-xs bg-background"
                      disabled={metadataTicker === item.ticker}
                    />
                    {articleDrafts[item.ticker]?.source
                      && articleDrafts[item.ticker]?.metadataUrl === articleDrafts[item.ticker]?.url.trim() && (
                       <p className="text-[11px] text-muted-foreground">
                         מקור שזוהה: <span className="font-medium text-foreground">{articleDrafts[item.ticker].source}</span>
                       </p>
                    )}
                  </form>

                  {articles.length > 0 && (
                    <div className="mt-3 space-y-2 border-t border-border pt-3">
                      <p className="text-[11px] font-medium text-muted-foreground">
                        מקורות שמורים ({articles.length})
                      </p>
                      {articles.map((article) => (
                        <div key={article.id} className="flex items-center gap-2 text-xs">
                          <a
                            href={article.url}
                            target="_blank"
                            rel="noreferrer"
                            className="min-w-0 flex-1 truncate text-primary hover:underline"
                            title={article.title}
                          >
                            {article.title}
                          </a>
                          <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground">
                            {ARTICLE_TYPE_LABELS[article.articleType ?? "other"]}
                          </span>
                          <button
                            type="button"
                            onClick={() => onRemoveArticle(item.ticker, article.id)}
                            className="rounded p-1 text-muted-foreground hover:bg-muted hover:text-destructive"
                            title="הסר מקור שמור"
                            aria-label="הסר מקור שמור"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </section>
              );
            })}
          </div>
        )}
        {articleError && <p className="text-xs text-destructive">{articleError}</p>}
        <p className="text-[11px] leading-relaxed text-muted-foreground">
          קישורים ציבוריים מנותחים אוטומטית. אם אתר חוסם קריאה, אפשר להשלים כותרת ותקציר ידנית.
        </p>
      </DialogContent>
    </Dialog>
  );
}